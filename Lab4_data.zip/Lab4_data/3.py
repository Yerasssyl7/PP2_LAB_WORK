from datetime import datetime

current_time = datetime.now()

clean_time = current_time.replace(microsecond=0)

print("С оригинальными микросекундами:", current_time)
print("Без микросекунд:", clean_time)
