from datetime import datetime, timedelta

current_date = datetime.today()

yesterday_date = current_date - timedelta(days=+1)
tomorrow_date = current_date + timedelta(days=+1)
print("Data time yesterday:", yesterday_date.strftime("%Y-%m-%d"))
print("Data time now:", current_date.strftime("%Y-%m-%d"))
print("Data next tomorrow:", tomorrow_date.strftime("%Y-%m-%d"))