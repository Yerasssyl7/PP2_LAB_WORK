from datetime import datetime, timedelta

current_date = datetime.today()

new_date = current_date - timedelta(days=5)

print("Data time now:", current_date.strftime("%Y-%m-%d"))
print("Data next five day:", new_date.strftime("%Y-%m-%d"))