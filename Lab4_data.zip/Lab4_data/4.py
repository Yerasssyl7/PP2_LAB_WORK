from datetime import datetime

date1 = datetime(2024, 3, 1, 12, 0, 0)
date2 = datetime(2024, 2, 25, 8, 30, 0)

difference = date1 - date2

seconds_difference = difference.total_seconds()

print("Разница в секундах:", seconds_difference)
