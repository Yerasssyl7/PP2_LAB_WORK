import re

s = input("Введите строку: ")

# Разбиваем строку по заглавным буквам
split_string = re.split(r"(?=[A-Z])", s)  # Используем позитивный lookahead

print("Результат:", split_string)
