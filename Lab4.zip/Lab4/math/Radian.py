import math

n = int(input("Input degree: "))

k = math.radians(n)

print (f"Output radian: {k}")

