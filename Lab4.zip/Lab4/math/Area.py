n = int(input("Height: "))
k = int(input("Base, first value: "))
m = int(input("Base, second value: "))
a = ((k + m)/2) * n
print(f"Expected Output: {a}")