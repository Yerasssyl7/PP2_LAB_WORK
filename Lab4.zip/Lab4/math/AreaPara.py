def area_para(base, height):
    return n * m

n = float(input("Length of base: "))
m = float(input("Height of parallelogram: "))

area = area_para(n, m)
print(f"Expected Output: {area}")