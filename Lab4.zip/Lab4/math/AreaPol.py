import math

n = int(input("Input number of sides: "))
m = int(input("Input the length of a side: "))
area = (n * m**2) / (4 * math.tan(math.pi / n))

if area.is_integer():
    print(f"The area of the polygon is: {int(area)}")
else:
    print(f"The area of the polygon is: {area:.2f}")