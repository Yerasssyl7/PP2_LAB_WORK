class even_numbers:
    def __init__(self, n):
        self.n = n
        self.current = 0
        
    def __iter__(self):
        return self
    
    def __next__(self):
        while self.current <= self.n:
            if self.current % 2 == 0:
                result = self.current
                self.current += 2
                return result
            else:
                self.current += 1
        raise StopIteration

n = int(input())

even_gen = even_numbers(n)

print(",".join(map(str, even_gen)))