def num(n):
    while n >= 0:
        yield n
        n -= 1 

n = int(input())

for value in num(n):
    print(value)