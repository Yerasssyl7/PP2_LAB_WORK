class Numbers:
    def __init__(self, n):
        self.n = n
        self.current = 0
        
    def __iter__(self):
        return self
    
    def __next__(self):
        if self.current > self.n:
            raise StopIteration
        
        result = self.current
        self.current += 12
        return result

n = int(input("Введите число n: "))

even_gen = Numbers(n)

print(",".join(map(str, list(even_gen))))