def multiple(numbers):
    result = 1
    for num in a:
        result *= num
    return result


n = int(input())
a = []
for i in range(0,n):
    a.append(int(input()))
    
print(multiple(a))