my_tuple = (True, 1, "Hello", [1, 2])

result = all(my_tuple)

print(result)
