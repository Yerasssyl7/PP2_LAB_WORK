import math
import time

n = int(input())
t = int(input())

time.sleep(t / 1000)

sqrt_n = math.sqrt(n)

print(f"Square root of {n} after {t} milliseconds is {sqrt_n}")
