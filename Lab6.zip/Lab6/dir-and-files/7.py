import shutil

def copy_file(source_path, destination_path):
    shutil.copy(source_path, destination_path)